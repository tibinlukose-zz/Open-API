<?php

/* 
 * Code By Team Zycon
 * www.zycon.in
 */
class SmsModel extends CI_Model{
    public function getApiData($id=''){
        if($id!=''){
        $sql="select * from sms where apiName=?";
        $data=$this->db->query($sql,array($id));
        $data=$data->row_array();
        return $data;
        }else{
            return false;
        }
    }
    public function deduct($id=''){
        if($id!=''){
        $sql="update sms set used=used+1 where apiName=?";
        $data=$this->db->query($sql,array($id));
        
        
        }
    }
}
