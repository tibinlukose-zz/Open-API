<?php

/* 
 * Code By Team Zycon
 * www.zycon.in
 */

class RateModel extends CI_Model{
    
    public function getGoldRate(){
        
        $homepage = file_get_contents('http://www.keralagold.com/daily-gold-prices.htm');
      
        $pos = strpos($homepage, "<span class=\"kg2b\">");
        
        $st = substr($homepage, $pos, 400);
        $st= substr($st, 80, 80);
        
        
        $st=  substr($st,"71","-2");
        //echo $st;
        $st=preg_replace("/[^0-9]/","",$st);
        
       return $st;
        
    }
}