<?php

/* 
 * Code By Team Zycon
 * www.zycon.in
 */

show_error("Invalid API URI");