<?php

/* 
 * Code By Team Zycon
 * www.zycon.in
 */

class Sms Extends CI_Controller{
    public function __construct() {
        parent::__construct();
    }
    public function send(){
        extract($this->uri->uri_to_assoc(3));
        if(isset($id) and isset($to) and isset($message)){
            $this->load->model('SmsModel');
            if($data=$this->SmsModel->getApiData($id)){
                if($data['package']>$data['used']){
                    if(sendSMS($message,$to)){
                       
                        $this->SmsModel->deduct($id);
                        $resp=array(
                        'id'=>$id,
                        'to'=>$to,
                        'message'=>$message,
                        'used'=>$data['used'],
                        'Total'=>$data['package'],
                        'status'=>'Success'
                    );
                    echo json_encode($resp);
                        
                    
                    
                    }else{
                        show_error('Error Sending SMS. Contact Provider ASAP');
                    }
                    
                    
                }else{
                    $resp=array(
                        'id'=>$id,
                        'to'=>$to,
                        'message'=>$message,
                        'used'=>$data['used'],
                        'Total'=>$data['package'],
                        'status'=>'Failed'
                    );
                    echo json_encode($resp);
                                       
                }
                
            }else{
                show_error('Invalid API Id');
            } 
            
        }else{
            $error="For sending any type of SMS message, the gateway requires to be sent various Parameters including
            ID for authentication purposes. All the parameters need to be sent via HTTP
            protocol using the GET method.";
            
            show_error($error);
        }
        
    }
    
}
