<?php

/* 
 * Code By Team Zycon
 * www.zycon.in
 */

class Rate extends CI_Controller{
    public function __construct() {
        parent::__construct();
    }


public function index(){
    $this->load->view('Rate/index');
}    
public function gold(){
    $this->load->model('RateModel');
    $pavan=$this->RateModel->getGoldRate();
    if($pavan>0){
    $gram=$pavan/8;
    $date=date('d-m-y');
    echo json_encode(array(
        'Gold_Pavan'=>$pavan,
        'Gold_Gram'=>$gram,
        'Date'=>$date,
        'Disclaimer'=>'Use this information at your risk    '
    ));
    }else{
        $date=date('d-m-y');
        echo json_encode(array(
            'Error'=>'API ERROR',
            'Date'=>$date
        ));
        
    }
    
}
}

