<?php

/* 
 * Code By Team Zycon
 * www.zycon.in
 */

function sendSMS($message,$phone){
        $control="http://bulksms.mysmsmantra.com/WebSMS/SMSAPI.jsp?username=tibinlukose&password=1822761314&sendername=IZYCON&mobileno={$phone}&message=";
        $control.=  urlencode($message);
        //echo $control;
        $curl = curl_init();
        // Set some options - we are passing in a useragent too here
        curl_setopt_array($curl, array(
                CURLOPT_RETURNTRANSFER => 1,
                CURLOPT_URL => $control,
                CURLOPT_USERAGENT => 'Zycon_API'
        ));
       
        $resp = curl_exec($curl);
        curl_close($curl);
        if(strpos($resp,'successfully')){
            return TRUE;
        }else{
            return FALSE;
        }
        
}